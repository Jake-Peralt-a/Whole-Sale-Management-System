# Wholesale Management System

This is a project that I did as part of the "Database Systems" course laboratory in my 5th semester during undergrad.

1. Backend (Database): MySQL version 5.7
2. Frontend (Web Technologies): HTML5 and PHP5
3. The web server was hosted using XAMPP v3.2.2

The project report has also been uploaded for more context.
